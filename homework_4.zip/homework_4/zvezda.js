"use strict"

let b= 1.005+Number.EPSILON
let a = Math.round(b*100)/100
console.log(a);


let value="135.58px"

console.log(parseFloat(value));


let c =50+"text";
if(isNaN(c)){
    console.log('результата NAN');
}

console.log(Math.max(10,58,39,-150,0));



console.log(Math.floor(58.858));